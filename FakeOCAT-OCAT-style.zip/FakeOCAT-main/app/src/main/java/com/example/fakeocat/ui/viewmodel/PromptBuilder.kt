package com.example.fakeocat.ui.viewmodel

/**
 * Prompt builder for the OCAT-style language-learning response.
 * The response is intentionally kept as Markdown + pronunciation markers so it can
 * stream safely while the UI turns every target-language sentence into an interactive item.
 */
class PromptBuilder {
    companion object {
        val supportedLanguages = listOf(
            "zh", "en", "ja", "ko", "es", "fr", "de", "pt", "ru", "it",
            "nl", "sv", "pl", "cs", "el", "he", "ar", "th", "vi", "id", "hi", "tr"
        )

        fun langDisplayName(code: String): String = when (code) {
            "zh" -> "中文"; "en" -> "English"; "ja" -> "日本語"; "ko" -> "한국어"
            "es" -> "Español"; "fr" -> "Français"; "de" -> "Deutsch"; "pt" -> "Português"
            "ru" -> "Русский"; "it" -> "Italiano"; "ar" -> "العربية"; "th" -> "ไทย"
            "vi" -> "Tiếng Việt"; "id" -> "Bahasa Indonesia"; "hi" -> "हिन्दी"; "tr" -> "Türkçe"
            "nl" -> "Nederlands"; "sv" -> "Svenska"; "pl" -> "Polski"; "cs" -> "Čeština"
            "el" -> "Ελληνικά"; "he" -> "עברית"; else -> code
        }

        fun langFullNameCn(code: String): String = when (code) {
            "zh" -> "中文"; "en" -> "英语"; "ja" -> "日语"; "ko" -> "韩语"; "es" -> "西班牙语"
            "fr" -> "法语"; "de" -> "德语"; "pt" -> "葡萄牙语"; "ru" -> "俄语"; "it" -> "意大利语"
            "ar" -> "阿拉伯语"; "th" -> "泰语"; "vi" -> "越南语"; "id" -> "印尼语"; "hi" -> "印地语"
            "tr" -> "土耳其语"; "nl" -> "荷兰语"; "sv" -> "瑞典语"; "pl" -> "波兰语"; "cs" -> "捷克语"
            "el" -> "希腊语"; "he" -> "希伯来语"; else -> code
        }

        private const val RESPONSE_RULES = """
你正在为一个类似 OCAT 的沉浸式英语学习 App 生成学习卡片。你的回答不是普通聊天，而是一份可以直接学习、播放、收藏的课程卡片。

【最重要的输出规则】
1. 第一行必须直接给出最自然、最口语化、真实生活中会说的目标语言翻译。不要先解释，不要说“当然可以”“以下是”。
2. 第一行翻译必须使用：TARGET_SENTENCE 标记。格式严格为：[TARGET_SENTENCE]目标语言句子[/TARGET_SENTENCE]。不要在标记内部加入 Markdown、括号或额外解释。
3. 后续严格按照以下顺序输出，不能调换、合并或省略：
   ### 句子解析
   ### 这个句子怎么用
   ### 重点词汇
   ### 示例
   ### 地道表达拓展
   ### 常见回复方式
   ### 练习
4. 所有目标语言的完整句子都必须单独一行，并使用 [SENTENCE]句子[/SENTENCE] 标记。每个句子都必须是完整、自然、可直接说出口的句子。
5. 目标语言句子不要放进代码块，不要使用表格，不要把多个句子写在同一行。
6. 每个目标语言句子后面可以紧跟中文解释，但目标语言句子本身必须独立一行。
7. 示例、地道表达拓展、常见回复方式里的每一个英文句子都必须单独成为 SENTENCE，方便 App 对每句话提供播放和收藏。
8. 重点词汇只讲真正值得学的词/短语：含义、语气、搭配、使用场景。不要堆词典式解释。
9. “这个句子怎么用”要讲真实使用场景、语气、适用对象，以及什么时候不建议用。
10. “地道表达拓展”给 3-5 个不同自然度/语气的表达，并说明区别。
11. “常见回复方式”给 3-5 个真实对话中可能收到的回复，每个回复都必须是 SENTENCE。
12. “练习”设计一个简短的填空或情景选择题，让用户真正用出这个句型；不要直接把答案写在题目后面。
13. 除目标语言句子外，所有解释使用用户母语。
14. 不要重复同一个句子。不要为了凑数量生成生硬例句。
15. 如果原文存在多种合理翻译，只把最自然、最口语的版本放第一行；其他版本放“地道表达拓展”。

【SENTENCE 标记】
正确：[SENTENCE]I’m gonna head home.[/SENTENCE]
错误：**I’m gonna head home.**（不要这样）
错误：`[SENTENCE]...[/SENTENCE]`（不要代码块）

App 会自动把每个 SENTENCE 渲染成“▶ 播放 + ☆ 收藏”的交互句卡。因此不要自己添加播放、收藏按钮文字。
"""

        private const val SYSTEM_PROMPT_HOW_TO_SAY = """
你是专业的口语语言学习教练。用户母语是 %1\$s，正在学习 %2\$s。
$RESPONSE_RULES
严格执行以上结构。目标语言是 %2\$s。
"""

        private const val SYSTEM_PROMPT_WHAT_MEANS = """
你是专业的语言学习教练。用户母语是 %1\$s，正在理解 %2\$s。
如果用户提供的是目标语言内容，第一部分仍然先给出最自然的中文/母语释义；随后按照 OCAT 学习卡片结构讲解原句。原句、示例句、拓展句、回复句都必须使用 [SENTENCE]...[/SENTENCE]。
$RESPONSE_RULES
"""

        private const val SYSTEM_PROMPT_FREE_CHAT = """
你是一个自然、友好的口语练习伙伴，同时必须保持 OCAT 式学习体验。
$RESPONSE_RULES
如果用户的问题不是翻译学习任务，也要尽量把真正值得学习的目标语言句子单独标记为 [SENTENCE]...[/SENTENCE]。
"""
    }

    fun buildSystemPrompt(mode: String, native: String, target: String): String {
        val nativeName = langFullNameCn(native)
        val targetName = langFullNameCn(target)
        val template = when (mode) {
            "HowToSay" -> SYSTEM_PROMPT_HOW_TO_SAY
            "WhatMeans" -> SYSTEM_PROMPT_WHAT_MEANS
            else -> SYSTEM_PROMPT_FREE_CHAT
        }
        return java.lang.String.format(template, nativeName, targetName)
    }

    fun buildUserPrompt(mode: String, userText: String, target: String): String {
        val targetName = langFullNameCn(target)
        return when (mode) {
            "HowToSay" -> "用户想表达：\"$userText\"。请直接按照 OCAT 学习卡片结构，用$targetName给出最自然的口语说法。第一行只放最自然的口语翻译，然后依次完成句子解析、使用方法、重点词汇、示例、地道表达拓展、常见回复方式、练习。"
            "WhatMeans" -> "请把「$userText」做成一张 OCAT 式学习卡：先给出最直接易懂的意思，再依次讲解句子、使用方法、重点词汇、示例、地道表达拓展、常见回复方式和练习。所有目标语言完整句子逐句标记为 [SENTENCE]...[/SENTENCE]。"
            else -> userText
        }
    }
}
