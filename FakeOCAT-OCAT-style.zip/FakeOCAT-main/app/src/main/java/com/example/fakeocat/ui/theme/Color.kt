package com.example.fakeocat.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryLight = Color(0xFFD0BCFF)
val SecondaryLight = Color(0xFFCCC2DC)
val TertiaryLight = Color(0xFFEFB8C8)

val PrimaryDark = Color(0xFF6650a4)
val SecondaryDark = Color(0xFF625b71)
val TertiaryDark = Color(0xFF7D5260)